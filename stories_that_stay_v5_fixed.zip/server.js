const express = require("express");
const session = require("express-session");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, "data", "data.json");

function loadDB() {
  if (!fs.existsSync(DB_FILE)) return { users: [], stories: [], purchases: [] };
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function saveDB(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
function id() { return crypto.randomUUID(); }

app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-secret-change-me",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:false}
}));

const upload = multer({dest:path.join(__dirname,"public","uploads")});

function page(title, body, extra="") {
return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title} — STORIES THAT STAY</title><link rel="stylesheet" href="/style.css"></head><body>
<nav><a class="brand" href="/">STORIES THAT STAY</a><div class="navlinks">
<a href="/">Library</a>${extra}</div></nav><main>${body}</main>
<footer>© ${new Date().getFullYear()} STORIES THAT STAY · Created by Nemlee Eddie</footer></body></html>`;
}
function requireReader(req,res,next){ if(!req.session.reader) return res.redirect("/login?next="+encodeURIComponent(req.originalUrl)); next(); }
function requireAdmin(req,res,next){ if(!req.session.admin) return res.redirect("/admin/login"); next(); }

app.get("/", (req,res)=>{
 const db=loadDB();
 const lang=req.query.lang==="sw"?"sw":"en";
 const cards=db.stories.map(s=>`<article class="card"><img src="${s.cover||"/placeholder.svg"}"><div><span class="pill">${s.price||2000} TSh · ${s.days||7} days</span>
 <h2>${lang==="sw" && s.titleSw ? s.titleSw : s.title}</h2><p>${lang==="sw" && s.descriptionSw ? s.descriptionSw : (s.description||"")}</p>
 <a class="btn" href="/story/${s.id}?lang=${lang}">${lang==="sw"?"Soma hadithi":"View story"}</a></div></article>`).join("");
 res.send(page("Library", `<section class="hero"><div><p class="eyebrow">COMICS · STORIES · ART</p><h1>Stories that stay with you.</h1>
 <p>Read original stories and comics from Nemlee Eddie.</p><div class="lang"><a href="/?lang=en">🇬🇧 English</a><a href="/?lang=sw">🇹🇿 Kiswahili</a></div></div></section>
 <div class="section-head"><h2>${lang==="sw"?"Hadithi zetu":"Our stories"}</h2><a href="/account">${lang==="sw"?"Akaunti yangu":"My account"}</a></div>
 <div class="grid">${cards||'<div class="empty">No stories published yet.</div>'}</div>`,
 `<a href="/account">Account</a><a href="/admin">Creator</a>`));
});

app.get("/signup",(req,res)=>res.send(page("Sign up",`<div class="auth"><h1>Create reader account</h1>
<form method="post"><label>Email<input name="email" type="email" required></label><label>Password<input name="password" type="password" minlength="6" required></label><button class="btn">Create account</button></form><p>Already have an account? <a href="/login">Log in</a></p></div>`)));
app.post("/signup",(req,res)=>{
 const db=loadDB(); const email=req.body.email.toLowerCase().trim();
 if(db.users.some(u=>u.email===email)) return res.send(page("Sign up",`<div class="auth"><h1>Account exists</h1><p><a href="/login">Log in</a></p></div>`));
 db.users.push({id:id(),email,password:req.body.password,createdAt:new Date().toISOString()}); saveDB(db);
 req.session.reader={id:db.users.at(-1).id,email}; res.redirect("/account");
});
app.get("/login",(req,res)=>res.send(page("Login",`<div class="auth"><h1>Reader login</h1><form method="post"><input type="hidden" name="next" value="${req.query.next||"/account"}">
<label>Email<input name="email" type="email" required></label><label>Password<input name="password" type="password" required></label><button class="btn">Log in</button></form><p>No account? <a href="/signup">Create one</a></p></div>`)));
app.post("/login",(req,res)=>{
 const db=loadDB(), email=req.body.email.toLowerCase().trim(), u=db.users.find(x=>x.email===email && x.password===req.body.password);
 if(!u) return res.send(page("Login",`<div class="auth"><h1>Login failed</h1><p>Check your email and password.</p><a href="/login">Try again</a></div>`));
 req.session.reader={id:u.id,email:u.email}; res.redirect(req.body.next||"/account");
});
app.post("/logout",(req,res)=>{req.session.destroy(()=>res.redirect("/"));});
app.get("/account",requireReader,(req,res)=>{
 const db=loadDB(); const purchases=db.purchases.filter(p=>p.userId===req.session.reader.id && p.status==="paid");
 const items=purchases.map(p=>{const s=db.stories.find(x=>x.id===p.storyId); if(!s)return "";
 const active=Date.now()<new Date(p.expiresAt).getTime();
 return `<div class="account-item"><img src="${s.cover||"/placeholder.svg"}"><div><h3>${s.title}</h3><p>${active?"Access active until "+new Date(p.expiresAt).toLocaleString():"Access expired"}</p>${active?`<a class="btn" href="/read/${s.id}">Continue reading</a>`:`<a class="btn" href="/story/${s.id}">Renew for ${s.price||2000} TSh</a>`}</div></div>`}).join("");
 res.send(page("My account",`<div class="section-head"><div><p class="eyebrow">READER ACCOUNT</p><h1>My library</h1><p>${req.session.reader.email}</p></div><form method="post" action="/logout"><button class="ghost">Log out</button></form></div><div class="stack">${items||"<div class='empty'>You have no purchased stories yet.</div>"}</div>`));
});

app.get("/story/:id",(req,res)=>{
 const db=loadDB(), s=db.stories.find(x=>x.id===req.params.id); if(!s)return res.status(404).send(page("Not found","<h1>Story not found</h1>"));
 const lang=req.query.lang==="sw"?"sw":"en"; const title=lang==="sw"&&s.titleSw?s.titleSw:s.title;
 let owned=false; if(req.session.reader){owned=db.purchases.some(p=>p.userId===req.session.reader.id&&p.storyId===s.id&&p.status==="paid"&&Date.now()<new Date(p.expiresAt).getTime());}
 res.send(page(title,`<div class="story-detail"><img class="cover-large" src="${s.cover||"/placeholder.svg"}"><div><p class="eyebrow">STORY</p><h1>${title}</h1>
 <p>${lang==="sw"&&s.descriptionSw?s.descriptionSw:(s.description||"")}</p><div class="price">${s.price||2000} TSh <small>/ ${s.days||7} days</small></div>
 ${owned?`<a class="btn big" href="/read/${s.id}">${lang==="sw"?"Endelea kusoma":"Continue reading"} →</a>`:`<a class="btn big" href="/checkout?storyId=${s.id}">${lang==="sw"?"Lipa na soma kwa siku 7":"Pay TSh "+(s.price||2000)+" · Read for 7 days"}</a>`}
 <div class="lang"><a href="/story/${s.id}?lang=en">🇬🇧 English</a><a href="/story/${s.id}?lang=sw">🇹🇿 Kiswahili</a></div></div></div>`));
});

app.get("/read/:id",requireReader,(req,res)=>{
 const db=loadDB(), s=db.stories.find(x=>x.id===req.params.id);
 const p=db.purchases.find(x=>x.userId===req.session.reader.id&&x.storyId===s?.id&&x.status==="paid"&&Date.now()<new Date(x.expiresAt).getTime());
 if(!s)return res.status(404).send(page("Not found","<h1>Story not found</h1>"));
 if(!p)return res.redirect("/story/"+s.id);
 const pages=(s.pages||[]).map(x=>x.url).filter(Boolean);
 res.send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${s.title} — STORIES THAT STAY</title><link rel="stylesheet" href="/reader.css"></head>
 <body><header class="reader-top"><a href="/story/${s.id}">← Back</a><strong>${s.title}</strong><span id="counter"></span></header>
 <div class="progress"><i id="bar"></i></div><main class="reader"><button id="prev">‹</button><div class="page-wrap"><img id="comic" src="" alt="${s.title} comic page"><div id="empty"></div></div><button id="next">›</button></main>
 <div class="reader-bottom"><span id="hint">Swipe or use the arrows</span><div><button id="prev2">Previous</button><button id="next2">Next</button></div></div>
 <script>const pages=${JSON.stringify(pages)};let i=0;const img=document.getElementById('comic'),bar=document.getElementById('bar'),counter=document.getElementById('counter');
 function show(){if(!pages.length){img.style.display='none';document.getElementById('empty').textContent='No comic pages uploaded yet.';return} img.src=pages[i];counter.textContent='Page '+(i+1)+' of '+pages.length;bar.style.width=((i+1)/pages.length*100)+'%';localStorage.setItem('sts:${s.id}',i)}
 function next(){if(i<pages.length-1){i++;show()}} function prev(){if(i>0){i--;show()}}
 document.getElementById('next').onclick=next;document.getElementById('next2').onclick=next;document.getElementById('prev').onclick=prev;document.getElementById('prev2').onclick=prev;
 i=Math.min(parseInt(localStorage.getItem('sts:${s.id}')||'0'),Math.max(0,pages.length-1));show();
 let x=0;document.querySelector('.page-wrap').addEventListener('touchstart',e=>x=e.changedTouches[0].clientX);document.querySelector('.page-wrap').addEventListener('touchend',e=>{let d=e.changedTouches[0].clientX-x;if(Math.abs(d)>45)d<0?next():prev()});
 document.addEventListener('keydown',e=>{if(e.key==='ArrowRight')next();if(e.key==='ArrowLeft')prev()});
 </script></body></html>`);
});

app.get("/checkout",(req,res)=>{
 if(!req.session.reader)return res.redirect("/login?next="+encodeURIComponent(req.originalUrl));
 const db=loadDB(),s=db.stories.find(x=>x.id===req.query.storyId); if(!s)return res.status(404).send(page("Checkout","<h1>Story not found</h1>"));
 res.send(page("Checkout",`<div class="checkout"><p class="eyebrow">SECURE CHECKOUT</p><h1>${s.title}</h1><p>7-day reading access</p><div class="price">${s.price||2000} TSh</div>
 <form method="post"><input type="hidden" name="storyId" value="${s.id}"><button class="btn big">Continue to payment</button></form>
 <p class="note">Payment-provider connection is prepared in this starter. Your actual receiving/settlement account is configured in your verified payment-provider account.</p></div>`));
});
app.post("/checkout",(req,res)=>{
 const db=loadDB(),s=db.stories.find(x=>x.id===req.body.storyId); if(!s||!req.session.reader)return res.status(400).send("Invalid checkout");
 const tx="STS-"+Date.now()+"-"+crypto.randomBytes(3).toString("hex");
 const purchase={id:id(),userId:req.session.reader.id,storyId:s.id,txRef:tx,status:"pending",createdAt:new Date().toISOString()};
 db.purchases.push(purchase);saveDB(db);
 // TODO: call the configured payment provider here, passing amount, currency TZS, tx_ref and redirect URL.
 res.send(page("Payment",`<div class="checkout"><h1>Payment ready</h1><p>Transaction reference: <strong>${tx}</strong></p><p>This v5 package has the payment flow wired as a safe integration point, but it is not live until you add your verified payment-provider credentials and deploy over HTTPS.</p><a class="btn" href="/account">Back to account</a></div>`));
});

app.get("/admin/login",(req,res)=>res.send(page("Creator login",`<div class="auth"><p class="eyebrow">CREATOR AREA</p><h1>Nemlee Eddie</h1><form method="post"><label>Email<input name="email" type="email" required></label><label>Password<input name="password" type="password" required></label><button class="btn">Log in</button></form></div>`)));
app.post("/admin/login",(req,res)=>{
 if(req.body.email===process.env.ADMIN_EMAIL&&req.body.password===process.env.ADMIN_PASSWORD){req.session.admin=true;return res.redirect("/admin")}
 res.send(page("Creator login","<div class='auth'><h1>Login failed</h1><a href='/admin/login'>Try again</a></div>"));
});
app.post("/admin/logout",(req,res)=>{req.session.admin=false;res.redirect("/")});
app.get("/admin",requireAdmin,(req,res)=>{
 const db=loadDB();
 const rows=db.stories.map(s=>`<div class="admin-story"><img src="${s.cover||"/placeholder.svg"}"><div><h3>${s.title}</h3><p>${s.pages?.length||0} pages · ${s.price||2000} TSh · ${s.days||7} days</p></div></div>`).join("");
 res.send(page("Creator dashboard",`<div class="section-head"><div><p class="eyebrow">PRIVATE CREATOR DASHBOARD</p><h1>Stories that stay</h1><p>Only you can publish and manage stories.</p></div><form method="post" action="/admin/logout"><button class="ghost">Log out</button></form></div>
 <div class="panel"><h2>Publish a story</h2><form method="post" action="/admin/story" enctype="multipart/form-data"><div class="two"><label>Title<input name="title" required></label><label>Kiswahili title<input name="titleSw"></label></div>
 <div class="two"><label>Description<textarea name="description"></textarea></label><label>Kiswahili description<textarea name="descriptionSw"></textarea></label></div>
 <div class="two"><label>Price (TSh)<input name="price" type="number" value="2000" min="1"></label><label>Access days<input name="days" type="number" value="7" min="1"></label></div>
 <label>Cover image<input name="cover" type="file" accept="image/*"></label><label>Comic pages <input name="pages" type="file" accept="image/*" multiple></label>
 <button class="btn">Publish story</button></form></div><div class="panel"><h2>Published stories</h2>${rows||"<p>No stories yet.</p>"}</div>`));
});
app.post("/admin/story",requireAdmin,upload.fields([{name:"cover",maxCount:1},{name:"pages",maxCount:200}]),(req,res)=>{
 const cover=req.files.cover?.[0], pages=(req.files.pages||[]).map(f=>({url:"/uploads/"+f.filename,name:f.originalname}));
 const db=loadDB(); db.stories.push({id:id(),title:req.body.title,titleSw:req.body.titleSw,description:req.body.description,descriptionSw:req.body.descriptionSw,price:Number(req.body.price||2000),days:Number(req.body.days||7),cover:cover?"/uploads/"+cover.filename:"",pages,createdAt:new Date().toISOString()}); saveDB(db); res.redirect("/admin");
});

app.get("/webhook/flutterwave",(req,res)=>res.status(200).send("ok"));
app.post("/webhook/flutterwave",(req,res)=>{ /* verify webhook signature before marking a purchase paid in production */ res.status(200).send("ok"); });

app.listen(PORT,()=>console.log(`STORIES THAT STAY running on http://localhost:${PORT}`));
