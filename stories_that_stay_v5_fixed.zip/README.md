# STORIES THAT STAY — v5

This version adds:
- English / Kiswahili language selector
- Reader accounts
- Private creator dashboard for Nemlee Eddie
- Story cover + comic page upload
- TSh 2,000 default price and 7-day access
- Mobile comic reader with next/previous buttons
- Swipe navigation and keyboard arrows
- Reading progress bar and saved page position
- Checkout integration point for a payment provider
- Purchase records and expiry structure

## Important
The payment connection is NOT live yet. To receive real money:
1. Create/verify your merchant/payment-provider account.
2. Configure your receiving/settlement bank or mobile-money account inside that provider.
3. Add the provider API credentials to `.env`.
4. Deploy the site over HTTPS.
5. Implement and verify the provider's webhook/signature before marking purchases paid.
6. Replace the development JSON database with a production database.
7. Replace plain-text development passwords with Argon2/bcrypt password hashing.
8. Use secure cookies, CSRF protection, rate limiting, and proper production session storage.

Never put your PIN, OTP, banking password, or mobile-money PIN in `.env` or source code.

## Run locally
npm install
copy .env.example .env
set ADMIN_EMAIL and ADMIN_PASSWORD
npm start

Then open http://localhost:3000
